from django.apps import AppConfig


class SurveyappConfig(AppConfig):
    name = 'surveyapp'
